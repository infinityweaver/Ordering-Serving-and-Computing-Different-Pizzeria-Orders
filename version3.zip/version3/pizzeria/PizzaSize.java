package pizzeria;

public enum PizzaSize
{
	Single, Double, Barkada
}