package pizzeria;

public enum PizzaBase
{
	Original, Thincrust
}