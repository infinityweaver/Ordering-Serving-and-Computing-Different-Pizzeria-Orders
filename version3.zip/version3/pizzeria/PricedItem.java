package pizzeria;

public interface PricedItem
{
	public double computePrice();
}