package pizzeria;

public enum ShakeSize
{
	Small, Medium, Large
}